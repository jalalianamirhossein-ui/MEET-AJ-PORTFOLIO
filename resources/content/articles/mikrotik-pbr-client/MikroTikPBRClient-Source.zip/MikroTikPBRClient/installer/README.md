# Installer source

`build_msi.py` creates an MSI from the complete, flat Windows x64 self-contained publish folder. It uses Python's standard library and the `wixl` compiler / `msibuild` database tool from GNOME msitools. The generated `.wxs` is included with the source release.

The MSI installs for the current Windows user into:

```text
%LOCALAPPDATA%\Programs\MikroTikPBRClient
```

It includes the verified application and its .NET/Windows Desktop Runtime, desktop and Start menu shortcuts, and a Start menu shortcut named **PBR Client Settings** that opens appsettings.json in Notepad. It writes installation markers only to HKCU. Uninstall is available through Windows Installed apps. The installer does not launch the application automatically or install a Windows service.

## Build

First run `Build.cmd` on Windows to produce the application's complete publish directory. Then compile the installer in a Linux/WSL environment with Python 3 and `wixl` installed. On Ubuntu/Debian, the compiler package is `wixl`; `msitools` supplies inspection/extraction tools.

```bash
python3 installer/build_msi.py \
  --payload artifacts/win-x64 \
  --output artifacts/MikroTikPBRClient-Setup-1.0.2-x64.msi
```

For authoring only, add `--emit-only`. `--wixl` and `--msibuild` can point to non-default executables. The generated `.wxs` refers to payload files through `$(var.PayloadDir)`, which the script supplies to the compiler. After compilation, the script sets the configuration component's documented NeverOverwrite flag using msibuild because wixl 0.103 does not expose that authoring attribute.

This release was compiled with wixl/msitools 0.103. Package tables and the extracted payload were inspected; installation/uninstallation on Windows was not executed here. The application payload itself was confirmed working on Windows by the user.

## Editing IP addresses

Edit the installed appsettings.json and restart the application. A source rebuild is unnecessary. To change default IPs in future distributions, edit `src/Pbr.Client/appsettings.json`, then rebuild the application and installer.

The configuration component uses NeverOverwrite to avoid replacing an existing installed configuration during repair. Back up appsettings.json before uninstalling. This initial package does not implement automatic upgrades; uninstall an older MSI before installing a new package and restore your saved settings afterward.

Microsoft references: [per-user installation](https://learn.microsoft.com/en-us/windows/win32/msi/installation-context), [packages without elevation](https://learn.microsoft.com/en-us/windows/win32/msi/authoring-packages-without-the-uac-dialog-box).
