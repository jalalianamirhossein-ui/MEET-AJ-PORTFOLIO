#!/usr/bin/env python3
"""Generate WiX-compatible authoring and optionally build an MSI with wixl.

The payload must be the complete self-contained win-x64 publish folder.
This script requires only Python's standard library; compiling requires wixl.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import subprocess
import uuid
import xml.etree.ElementTree as ET

NS = "http://schemas.microsoft.com/wix/2006/wi"
UPGRADE_CODE = "A73CB7E5-094D-4C79-91A5-65B7A0BA31E7"
COMPONENT_NAMESPACE = uuid.UUID("A35CF610-F778-4565-AC14-E89AB9D28043")
ET.register_namespace("", NS)


def child(parent: ET.Element, tag: str, **attrs: str) -> ET.Element:
    return ET.SubElement(parent, f"{{{NS}}}{tag}", attrs)


def build_authoring(payload: Path, version: str, output: Path) -> int:
    required = ["MikroTikPBRClient.exe", "MikroTikPBRClient.dll", "appsettings.json",
                "hostfxr.dll", "hostpolicy.dll", "coreclr.dll", "PresentationFramework.dll"]
    for filename in required:
        if not (payload / filename).is_file():
            raise ValueError(f"Incomplete self-contained payload: missing {filename}")
    parts = version.split(".")
    if len(parts) != 3 or not all(p.isdigit() for p in parts):
        raise ValueError("MSI version must have three numeric parts, for example 1.0.2")
    if not (int(parts[0]) <= 255 and int(parts[1]) <= 255 and int(parts[2]) <= 65535):
        raise ValueError("MSI version exceeds Windows Installer limits")

    wix = ET.Element(f"{{{NS}}}Wix")
    product = child(wix, "Product", Id="*", Name="MikroTik PBR Client", Language="1033",
                    Version=version, Manufacturer="PBR Client Project", UpgradeCode=UPGRADE_CODE)
    child(product, "Package", InstallerVersion="500", Compressed="yes",
          InstallScope="perUser",
          Description="MikroTik PBR Client with an app-local .NET Desktop Runtime")
    child(product, "Media", Id="1", Cabinet="payload.cab", EmbedCab="yes")
    child(product, "Property", Id="ARPNOMODIFY", Value="1")
    child(product, "Property", Id="ARPCOMMENTS", Value="Connect and disconnect using configurable ICMP triggers")
    child(product, "Icon", Id="PbrClient.exe", SourceFile="$(var.PayloadDir)/MikroTikPBRClient.exe")
    child(product, "Property", Id="ARPPRODUCTICON", Value="PbrClient.exe")
    arch = child(product, "Condition", Message="This package requires 64-bit Windows.")
    arch.text = "VersionNT64"

    target = child(product, "Directory", Id="TARGETDIR", Name="SourceDir")
    local = child(target, "Directory", Id="LocalAppDataFolder")
    programs = child(local, "Directory", Id="UserProgramsDir", Name="Programs")
    install = child(programs, "Directory", Id="INSTALLDIR", Name="MikroTikPBRClient")
    menu = child(target, "Directory", Id="ProgramMenuFolder")
    app_menu = child(menu, "Directory", Id="ApplicationMenuDir", Name="MikroTik PBR Client")
    child(target, "Directory", Id="DesktopFolder")
    child(target, "Directory", Id="SystemFolder")

    feature = child(product, "Feature", Id="Complete", Title="MikroTik PBR Client", Level="1")
    files = sorted(p for p in payload.rglob("*") if p.is_file())
    # The application is deliberately deployed as a flat folder.
    if any(p.parent != payload for p in files):
        raise ValueError("Payload contains subfolders; use a flat self-contained publish directory")
    for file in files:
        relative = file.name
        token = uuid.uuid5(COMPONENT_NAMESPACE, relative.lower()).hex
        component_id = "C_" + token
        attrs = dict(Id=component_id, Guid=str(uuid.uuid5(COMPONENT_NAMESPACE, "component:" + relative.lower())).upper(),
                     Win64="yes")
        component = child(install, "Component", **attrs)
        child(component, "File", Id="F_" + token, Name=relative,
              Source="$(var.PayloadDir)/" + relative, DiskId="1")
        child(component, "RegistryValue", Root="HKCU", Key="Software\\MikroTikPBRClient\\Installer",
              Name=component_id, Type="integer", Value="1", KeyPath="yes")
        child(feature, "ComponentRef", Id=component_id)

    shortcuts = child(app_menu, "Component", Id="ApplicationShortcuts",
                      Guid="353C9B42-4212-4459-8F0C-82C9F1F0A342", Win64="yes")
    child(shortcuts, "Shortcut", Id="StartMenuShortcut", Name="MikroTik PBR Client",
          Target="[INSTALLDIR]MikroTikPBRClient.exe", WorkingDirectory="INSTALLDIR",
          Icon="PbrClient.exe", IconIndex="0")
    child(shortcuts, "Shortcut", Id="SettingsShortcut", Name="PBR Client Settings",
          Target="[SystemFolder]notepad.exe", Arguments='"[INSTALLDIR]appsettings.json"',
          WorkingDirectory="INSTALLDIR")
    child(shortcuts, "Shortcut", Id="DesktopShortcut", Directory="DesktopFolder",
          Name="MikroTik PBR Client", Target="[INSTALLDIR]MikroTikPBRClient.exe",
          WorkingDirectory="INSTALLDIR", Icon="PbrClient.exe", IconIndex="0")
    child(shortcuts, "RemoveFolder", Id="RemoveMenuFolder", On="uninstall")
    child(shortcuts, "RegistryValue", Root="HKCU", Key="Software\\MikroTikPBRClient",
          Name="InstallDirectory", Type="string", Value="[INSTALLDIR]", KeyPath="yes")
    child(feature, "ComponentRef", Id="ApplicationShortcuts")
    ET.indent(wix, space="  ")
    output.parent.mkdir(parents=True, exist_ok=True)
    ET.ElementTree(wix).write(output, encoding="utf-8", xml_declaration=True)
    return len(files)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--payload", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True, help="Destination .msi path")
    parser.add_argument("--version", default="1.0.2")
    parser.add_argument("--wixl", default="wixl")
    parser.add_argument("--msibuild", default="msibuild")
    parser.add_argument("--emit-only", action="store_true")
    args = parser.parse_args()
    payload = args.payload.resolve(strict=True)
    output = args.output.resolve()
    wxs = output.with_suffix(".wxs")
    count = build_authoring(payload, args.version, wxs)
    print(f"Authored {count} payload files: {wxs}")
    if not args.emit_only:
        subprocess.run([args.wixl, "-a", "x64", "-D", f"PayloadDir={payload}", "-o", str(output), str(wxs)], check=True)
        # wixl 0.103 does not expose Component/NeverOverwrite. Set the documented
        # MSI bits explicitly: RegistryKeyPath (4) | NeverOverwrite (128) | 64bit (256).
        token = uuid.uuid5(COMPONENT_NAMESPACE, "appsettings.json").hex
        query = f"UPDATE `Component` SET `Attributes` = 388 WHERE `Component` = 'C_{token}'"
        subprocess.run([args.msibuild, str(output), "-q", query], check=True)
        print(f"Installer ready: {output}")


if __name__ == "__main__":
    main()
