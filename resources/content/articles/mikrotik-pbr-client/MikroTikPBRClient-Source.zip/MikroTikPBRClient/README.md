# MikroTik PBR Client

A minimal Windows WPF/.NET 8 client that sends an ICMP trigger when its power button is clicked.

The MSI edition installs for the current user into `%LOCALAPPDATA%\Programs\MikroTikPBRClient` and adds application shortcuts plus a **PBR Client Settings** shortcut to open the JSON settings. See `CHANGE-IP.fa.md` for editing IPs without rebuilding and `installer/README.md` for the installer source/build process.

| Request | Destination |
| --- | --- |
| Connect | `10.10.10.10` |
| Disconnect | `11.11.11.11` |

Install the [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0) on Windows, extract the source archive, and run `Build.cmd`. It publishes a self-contained Windows x64 folder into `artifacts\win-x64`. Keep **all** output files together, including appsettings.json, hostfxr.dll and the other runtime libraries. Do not copy just the EXE. You may also open the solution in Visual Studio with .NET desktop development installed.

The Portable-v1.0.2 package supersedes the previous single-file packages. It uses an ordinary apphost with app-local hosting/runtime libraries, without bundle extraction or a global .NET installation.

The main button alternates requests after an ICMP acknowledgment. A separate **Send disconnect** button can always send OFF, including after restarting the app. The program never probes or changes the router at startup, never pings continuously, and never sends OFF on exit. It does not require elevation.

An echo reply is not confirmation that PBR is enabled/disabled. The UI reports **Connect requested** / **Disconnect requested**. On timeout the request may already have taken effect; the UI reports an unknown state. OFF waits a configurable scheduler grace period after an echo reply, but does not query the address list. Reopening the app starts in an unknown state, rather than falsely claiming disconnection.

The RouterOS trigger, address lists, removal scheduler, PBR route, FastTrack exceptions and any required NAT must already be configured. **11.11.11.11 is public:** configure it deliberately as a local MikroTik control address with a LAN route; do not send the OFF ping to an unrelated Internet host. Both control destinations must reach the correct router, and ICMP must be permitted from the intended LAN. Existing sessions may retain NAT/FastTrack state across a route switch.

Edit the IPv4 addresses, retry/timeout values and disconnect grace period in `appsettings.json`, then restart the app. The program validates settings before opening its window.

Run `Check.cmd` to execute the eight mock-based core checks; no real network packets are sent by those tests. See `VALIDATION.md` for the checks actually completed for this delivery.

See [README.fa.md](README.fa.md) for the Persian operating guide.
