using System.IO;
using System.Text.Json;
using System.Windows;
using Pbr.Core;

namespace Pbr.Client;

public partial class App : Application
{
    private Mutex? _instanceMutex;
    private bool _ownsMutex;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        _instanceMutex = new Mutex(true, "Local\\MikroTikPBRClient-1", out _ownsMutex);
        if (!_ownsMutex)
        {
            MessageBox.Show("PBR Client is already running. Use its open window.", "PBR Client");
            Shutdown();
            return;
        }
        try
        {
            var path = Path.Combine(AppContext.BaseDirectory, "appsettings.json");
            var settings = File.Exists(path)
                ? JsonSerializer.Deserialize<ClientSettings>(File.ReadAllText(path))
                  ?? throw new InvalidDataException("appsettings.json is empty.")
                : new ClientSettings();
            settings.Validate();
            var window = new MainWindow(settings);
            MainWindow = window;
            window.Show();
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or JsonException or ArgumentException)
        {
            MessageBox.Show($"Cannot start the client:\n{ex.Message}\n\nFix appsettings.json and restart.",
                "PBR Client", MessageBoxButton.OK, MessageBoxImage.Error);
            Shutdown(1);
        }
    }

    protected override void OnExit(ExitEventArgs e)
    {
        if (_ownsMutex) _instanceMutex?.ReleaseMutex();
        _instanceMutex?.Dispose();
        base.OnExit(e);
    }
}
