using System.Windows;
using System.Windows.Media;
using Pbr.Core;

namespace Pbr.Client;

public partial class MainWindow : Window
{
    private readonly ClientSettings _settings;
    private readonly TriggerService _service;
    private readonly CancellationTokenSource _lifetime = new();
    private bool _nextEnable = true;
    private bool _busy;
    private bool _closed;

    public MainWindow(ClientSettings settings)
    {
        InitializeComponent();
        _settings = settings;
        _service = new TriggerService(settings, new PingTransport());
        EnableIpText.Text = settings.EnableTriggerIp;
        DisableIpText.Text = settings.DisableTriggerIp;
    }

    private async void ConnectButton_Click(object sender, RoutedEventArgs e) => await ExecuteAsync(_nextEnable);
    private async void DisconnectButton_Click(object sender, RoutedEventArgs e) => await ExecuteAsync(false);

    private async Task ExecuteAsync(bool enable)
    {
        if (_busy || _closed) return;
        _busy = true;
        ConnectButton.IsEnabled = DisconnectButton.IsEnabled = false;
        StatusText.Text = enable ? "Sending connect..." : "Sending disconnect...";
        DetailText.Text = "Waiting for an ICMP echo reply.";
        try
        {
            var result = await _service.SendAsync(enable, _lifetime.Token);
            if (_closed) return;
            if (!result.Acknowledged)
            {
                ShowUnknown($"{result.Address}: {result.Detail}\nRequest may have reached the router. You can retry or send disconnect.");
                return;
            }
            if (!enable && _settings.DisconnectGraceMs > 0)
            {
                StatusText.Text = "Disconnect request acknowledged...";
                DetailText.Text = "Allowing time for the router's removal scheduler.";
                await Task.Delay(_settings.DisconnectGraceMs, _lifetime.Token);
            }
            if (_closed) return;
            _nextEnable = !enable;
            ConnectButton.Background = Brush(enable ? "#288760" : "#695374");
            StatusText.Foreground = Brush(enable ? "#79DEAF" : "#BDA4CD");
            StatusText.Text = enable ? "Connect requested" : "Disconnect requested";
            ActionText.Text = enable ? "Tap to disconnect" : "Tap to connect";
            DetailText.Text = $"{result.Address} replied in {result.RoundtripMs} ms.\nRouter state remains unverified.";
        }
        catch (OperationCanceledException) when (_lifetime.IsCancellationRequested) { }
        catch (Exception ex)
        {
            if (!_closed) ShowUnknown($"Unable to complete the request: {ex.Message}");
        }
        finally
        {
            _busy = false;
            if (!_closed) ConnectButton.IsEnabled = DisconnectButton.IsEnabled = true;
        }
    }

    private void ShowUnknown(string detail)
    {
        StatusText.Text = "State unknown";
        StatusText.Foreground = Brush("#EDB975");
        ConnectButton.Background = Brush("#776043");
        ActionText.Text = _nextEnable ? "Retry connect" : "Retry disconnect";
        DetailText.Text = detail;
    }

    private static SolidColorBrush Brush(string value) => new((Color)ColorConverter.ConvertFromString(value));

    protected override void OnClosed(EventArgs e)
    {
        _closed = true;
        _lifetime.Cancel();
        // Closing never sends a trigger; MikroTik keeps its current policy state.
        base.OnClosed(e);
    }
}
