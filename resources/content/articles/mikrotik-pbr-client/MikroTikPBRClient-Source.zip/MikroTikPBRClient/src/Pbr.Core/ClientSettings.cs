using System.Net;
using System.Net.Sockets;

namespace Pbr.Core;

public sealed record ClientSettings
{
    public string EnableTriggerIp { get; init; } = "10.10.10.10";
    public string DisableTriggerIp { get; init; } = "11.11.11.11";
    public int TimeoutMs { get; init; } = 1500;
    public int Attempts { get; init; } = 3;
    public int RetryDelayMs { get; init; } = 300;
    public int DisconnectGraceMs { get; init; } = 1200;

    public void Validate()
    {
        ValidateAddress(EnableTriggerIp, nameof(EnableTriggerIp));
        ValidateAddress(DisableTriggerIp, nameof(DisableTriggerIp));
        if (IPAddress.Parse(EnableTriggerIp).Equals(IPAddress.Parse(DisableTriggerIp)))
            throw new ArgumentException("Connect and disconnect IPs must differ.");
        if (TimeoutMs is < 100 or > 10000 || Attempts is < 1 or > 5 ||
            RetryDelayMs is < 0 or > 3000 || DisconnectGraceMs is < 0 or > 10000)
            throw new ArgumentException("Invalid timeout, retry count, or delay in appsettings.json.");
    }

    private static void ValidateAddress(string value, string name)
    {
        if (!IPAddress.TryParse(value, out var ip) || ip.AddressFamily != AddressFamily.InterNetwork)
            throw new ArgumentException($"{name} must be a literal IPv4 address.");
        var bytes = ip.GetAddressBytes();
        if (bytes[0] is 0 or 127 || bytes[0] >= 224 || ip.Equals(IPAddress.Any))
            throw new ArgumentException($"{name} must be a unicast, non-loopback IPv4 address.");
    }
}
