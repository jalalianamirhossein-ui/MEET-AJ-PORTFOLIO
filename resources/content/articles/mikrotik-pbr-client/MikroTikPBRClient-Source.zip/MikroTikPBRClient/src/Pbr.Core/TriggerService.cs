using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;

namespace Pbr.Core;

public sealed record EchoResult(bool Success, long RoundtripMs, string Detail);
public sealed record TriggerResult(bool Acknowledged, string Address, int Attempts, long RoundtripMs, string Detail);

public interface IEchoTransport
{
    Task<EchoResult> SendAsync(string address, int timeoutMs, CancellationToken cancellationToken);
}

public sealed class PingTransport : IEchoTransport
{
    public async Task<EchoResult> SendAsync(string address, int timeoutMs, CancellationToken cancellationToken)
    {
        using var ping = new Ping();
        var target = IPAddress.Parse(address);
        var reply = await ping.SendPingAsync(target, TimeSpan.FromMilliseconds(timeoutMs),
            Array.Empty<byte>(), null, cancellationToken).ConfigureAwait(false);
        var success = reply.Status == IPStatus.Success && target.Equals(reply.Address);
        return new EchoResult(success, reply.RoundtripTime, reply.Status.ToString());
    }
}

// An echo reply acknowledges ICMP only. It cannot verify the router's address list or route.
public sealed class TriggerService
{
    private readonly ClientSettings _settings;
    private readonly IEchoTransport _transport;

    public TriggerService(ClientSettings settings, IEchoTransport transport)
    {
        settings.Validate();
        _settings = settings;
        _transport = transport;
    }

    public async Task<TriggerResult> SendAsync(bool enable, CancellationToken cancellationToken = default)
    {
        string address = enable ? _settings.EnableTriggerIp : _settings.DisableTriggerIp;
        string detail = "No echo reply.";
        for (int attempt = 1; attempt <= _settings.Attempts; attempt++)
        {
            cancellationToken.ThrowIfCancellationRequested();
            try
            {
                var reply = await _transport.SendAsync(address, _settings.TimeoutMs, cancellationToken)
                    .ConfigureAwait(false);
                if (reply.Success)
                    return new TriggerResult(true, address, attempt, reply.RoundtripMs, "ICMP acknowledged.");
                detail = reply.Detail;
            }
            catch (Exception ex) when (ex is PingException or SocketException)
            {
                detail = ex.InnerException?.Message ?? ex.Message;
            }
            if (attempt < _settings.Attempts)
                await Task.Delay(_settings.RetryDelayMs, cancellationToken).ConfigureAwait(false);
        }
        return new TriggerResult(false, address, _settings.Attempts, 0, detail);
    }
}
