# راهنمای MikroTik PBR Client

برنامه ویندوزی WPF با .NET 8، یک دکمه برای ارسال فرمان اتصال و قطع به MikroTik دارد.

نسخه MSI برای کاربر فعلی در `%LOCALAPPDATA%\Programs\MikroTikPBRClient` نصب می‌شود. میان‌بر **PBR Client Settings** در منوی Start، فایل تنظیمات را باز می‌کند. راهنمای تغییر IP بدون Build مجدد در `CHANGE-IP.fa.md` و فایل‌های ساخت نصب‌کننده در پوشه `installer` قرار دارند.

| عمل | آدرس Ping |
| --- | --- |
| اتصال | `10.10.10.10` |
| قطع | `11.11.11.11` |

## ساخت فایل اجرایی

۱. فایل ZIP را Extract کنید.
۲. [.NET 8 SDK برای Windows x64](https://dotnet.microsoft.com/download/dotnet/8.0) را نصب کنید. SDK برای ساخت لازم است؛ Runtime به‌تنهایی کافی نیست.
۳. `Build.cmd` را اجرا کنید. اولین ساخت برای دریافت وابستگی‌های رسمی Microsoft به اینترنت نیاز دارد.
۴. خروجی در `artifacts\win-x64` قرار می‌گیرد. فایل `MikroTikPBRClient.exe` را اجرا کنید و تمام فایل‌های خروجی را کنار آن نگه دارید. فقط EXE را به محل دیگری منتقل نکنید.

خروجی Build.cmd شامل Runtime است؛ کامپیوتر مقصد به نصب جداگانه .NET نیاز ندارد. پروژه را می‌توانید از طریق `MikroTikPBRClient.sln` در Visual Studio دارای پشتیبانی .NET 8 و workload «.NET desktop development» نیز باز کنید.

نسخه بسته‌بندی `Portable-v1.0.2` پوشه‌ای است و فایل‌های `hostfxr.dll`، `hostpolicy.dll`، `coreclr.dll` و Runtime ویندوزی را کنار EXE دارد. این بسته جایگزین نسخه‌های تک‌فایلی قبلی شده است.

## استفاده

- در اولین اجرا، وضعیت واقعی روتر مشخص نیست. برنامه خودکار Ping نمی‌فرستد.
- کلیک روی دکمه بزرگ، درخواست اتصال را ارسال می‌کند. پس از پاسخ Echo، دکمه سبز می‌شود و کلیک بعدی درخواست قطع را می‌فرستد.
- پس از پاسخ به فرمان قطع، برنامه به‌اندازه `DisconnectGraceMs` برای Scheduler روتر مکث می‌کند. این مکث تأیید اجرای Script نیست.
- `Send disconnect` در هر وضعیت، فرمان قطع می‌فرستد؛ برای بازیابی بعد از بازکردن مجدد برنامه نیز قابل استفاده است.
- پاسخ Ping فقط دریافت ICMP را تأیید می‌کند، نه عضویت در Address List یا تغییر مسیر واقعی. به همین دلیل وضعیت «Connect requested» یا «Disconnect requested» نمایش داده می‌شود.
- در Timeout ممکن است درخواست به روتر رسیده باشد و پاسخ برگشت مسدود شده باشد. برنامه وضعیت را نامشخص اعلام می‌کند.
- بستن برنامه فرمان قطع نمی‌فرستد؛ وضعیت روتر باقی می‌ماند. برنامه سرویس، VPN tunnel یا Firewall نصب نمی‌کند و درخواست Administrator ندارد.

## پیش‌نیاز MikroTik

سناریوی Ping Trigger باید از قبل روی MikroTik تنظیم شده باشد. IPهای Trigger قبلی را در Ruleها و Control Interface با آدرس‌های بالا جایگزین کنید. هر دو آدرس باید از کلاینت به روتر صحیح برسند، و ICMP Echo Request/Reply برای LAN مجاز باشد.

`11.11.11.11` آدرس عمومی است. برای این سناریو باید عمداً به‌عنوان آدرس Control روی MikroTik محلی تعریف و از LAN به همان روتر هدایت شود؛ نباید Ping قطع به اینترنت ارسال شود. پاسخ یک میزبان عمومی هیچ ارتباطی با تغییر PBR ندارد.

Ruleهای Enable/Disable باید ICMP type `8:0` را فقط از LAN موردنظر بپذیرند. شبکه‌های داخلی و آدرس‌های خود روتر را از Mark Routing مستثنی کنید. ترتیب Mangle، FastTrack، NAT و مسیر Routing Table را مطابق کانفیگ واقعی بررسی کنید. قطع با Scheduler دوره‌ای انجام می‌شود؛ پاسخ Echo قطع قبل از حذف Address List ممکن است دریافت شود.

برای بررسی در RouterOS، با نام Address List استفاده‌شده در سناریوی قبلی:

```rsc
/ip firewall address-list print where list="PBR-ACTIVE"
/ip firewall address-list print where list="PBR-REMOVE"
/ip firewall mangle print stats
/system scheduler print detail
```

پس از اتصال، عضویت IP کلاینت در لیست فعال و تغییر Public IP را بررسی کنید. بعد از قطع، حذف IP و برگشت Public IP را بررسی کنید. Sessionهای موجود به‌علت FastTrack یا Connection Tracking لزوماً فوراً تغییر مسیر نمی‌دهند.

## تنظیمات

آدرس‌ها، Timeout و Retry در `appsettings.json` قابل تغییرند. بعد از تغییر، برنامه را دوباره باز کنید. نام کلیدها باید دقیقاً مانند فایل نمونه باشد. فایل نامعتبر باعث نمایش خطا و جلوگیری از شروع برنامه می‌شود.

```json
{
  "EnableTriggerIp": "10.10.10.10",
  "DisableTriggerIp": "11.11.11.11",
  "TimeoutMs": 1500,
  "Attempts": 3,
  "RetryDelayMs": 300,
  "DisconnectGraceMs": 1200
}
```

## تست

`Check.cmd` هشت تست منطق برنامه را با Mock Transport اجرا می‌کند و به هیچ آدرسی Ping واقعی نمی‌فرستد. برای نتیجه اعتبارسنجی این تحویل، `VALIDATION.md` را ببینید.

## مستندات Microsoft

- [Ping.SendPingAsync](https://learn.microsoft.com/en-us/dotnet/api/system.net.networkinformation.ping.sendpingasync?view=net-8.0)
- [Single-file deployment](https://learn.microsoft.com/en-us/dotnet/core/deploying/single-file/overview)
- [Windows targeting on Linux](https://learn.microsoft.com/en-us/dotnet/core/tools/sdk-errors/netsdk1100)
