using System.Net.NetworkInformation;
using Pbr.Core;

int count = 0;
var settings = new ClientSettings { RetryDelayMs = 0 };

async Task Check(string name, Func<Task> test)
{
    await test();
    Console.WriteLine($"PASS {name}");
    count++;
}
void Require(bool value, string message)
{
    if (!value) throw new InvalidOperationException(message);
}

await Check("connect uses 10.10.10.10, succeeds without extra sends", async () =>
{
    var fake = new FakeTransport((_, _) => new EchoResult(true, 8, "Success"));
    var result = await new TriggerService(settings, fake).SendAsync(true);
    Require(result.Acknowledged && result.Address == "10.10.10.10" && fake.Calls == 1 && result.RoundtripMs == 8, "Wrong enable behavior");
});
await Check("disconnect uses 11.11.11.11", async () =>
{
    var fake = new FakeTransport((_, _) => new EchoResult(true, 2, "Success"));
    var result = await new TriggerService(settings, fake).SendAsync(false);
    Require(result.Address == "11.11.11.11" && fake.LastAddress == result.Address, "Wrong OFF address");
});
await Check("timeout followed by success retries once", async () =>
{
    var fake = new FakeTransport((call, _) => new EchoResult(call == 2, 1, "TimedOut"));
    var result = await new TriggerService(settings, fake).SendAsync(true);
    Require(result.Acknowledged && result.Attempts == 2 && fake.Calls == 2, "Wrong retry behavior");
});
await Check("all timeouts produce unknown, never acknowledged", async () =>
{
    var fake = new FakeTransport((_, _) => new EchoResult(false, 0, "TimedOut"));
    var result = await new TriggerService(settings, fake).SendAsync(true);
    Require(!result.Acknowledged && fake.Calls == 3 && result.Detail == "TimedOut", "False positive");
});
await Check("PingException is bounded by retry limit", async () =>
{
    var fake = new FakeTransport((_, _) => throw new PingException("Network unavailable"));
    var result = await new TriggerService(settings, fake).SendAsync(false);
    Require(!result.Acknowledged && fake.Calls == 3, "Exception not handled");
});
await Check("cancellation sends no trigger", async () =>
{
    var fake = new FakeTransport((_, _) => new EchoResult(true, 0, "Success"));
    using var cts = new CancellationTokenSource();
    cts.Cancel();
    try { await new TriggerService(settings, fake).SendAsync(true, cts.Token); throw new Exception("Not cancelled"); }
    catch (OperationCanceledException) { Require(fake.Calls == 0, "Sent after cancellation"); }
});
await Check("equal addresses and invalid settings rejected", () =>
{
    foreach (var invalid in new[] {
        settings with { DisableTriggerIp = "10.10.10.10" },
        settings with { EnableTriggerIp = "example.invalid" },
        settings with { Attempts = 0 },
        settings with { TimeoutMs = -1 },
        settings with { EnableTriggerIp = "127.0.0.1" } })
    {
        try { invalid.Validate(); throw new Exception("Invalid settings accepted"); }
        catch (ArgumentException) { }
    }
    return Task.CompletedTask;
});
await Check("explicit OFF is independent of previous local state", async () =>
{
    var fake = new FakeTransport((_, _) => new EchoResult(true, 0, "Success"));
    var service = new TriggerService(settings, fake);
    await service.SendAsync(false);
    Require(fake.LastAddress == "11.11.11.11", "Cannot recover with OFF on startup");
});
Console.WriteLine($"{count} checks passed. No network packets sent (mock transport).");

sealed class FakeTransport(Func<int, string, EchoResult> behavior) : IEchoTransport
{
    public int Calls { get; private set; }
    public string? LastAddress { get; private set; }
    public Task<EchoResult> SendAsync(string address, int timeoutMs, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        Calls++;
        LastAddress = address;
        return Task.FromResult(behavior(Calls, address));
    }
}
