@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>&1
if errorlevel 1 (
    echo Install the .NET 8 SDK from https://dotnet.microsoft.com/download/dotnet/8.0
    echo Then run Build.cmd again.
    pause
    exit /b 1
)
echo Building self-contained Windows x64 folder...
dotnet publish "src\Pbr.Client\Pbr.Client.csproj" -c Release -r win-x64 --self-contained true -p:PublishSingleFile=false -p:DebugType=None -p:DebugSymbols=false -o "artifacts\win-x64"
if errorlevel 1 (
    echo Build failed. Read the error above.
    pause
    exit /b 1
)
echo.
echo Ready: artifacts\win-x64\MikroTikPBRClient.exe
echo Keep ALL files in this folder together. Do not copy only the executable.
start "" "%~dp0artifacts\win-x64"
pause
