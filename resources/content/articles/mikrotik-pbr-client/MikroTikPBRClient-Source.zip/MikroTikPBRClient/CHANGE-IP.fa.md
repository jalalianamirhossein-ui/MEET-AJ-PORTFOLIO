# تغییر IP اتصال و قطع

برای تغییر IPها لازم نیست کد را تغییر دهید یا برنامه را دوباره Build کنید.

۱. برنامه را ببندید.
۲. در نسخه نصبی، از منوی Start، میان‌بر **PBR Client Settings** را باز کنید. همچنین می‌توانید فایل زیر را مستقیماً در Notepad باز کنید:

```text
%LOCALAPPDATA%\Programs\MikroTikPBRClient\appsettings.json
```

در نسخه Portable، همین فایل کنار EXE است.

۳. مقدار این دو کلید را تغییر دهید. نام کلیدها و کوتیشن‌ها را حفظ کنید:

```json
{
  "EnableTriggerIp": "10.10.10.10",
  "DisableTriggerIp": "11.11.11.11",
  "TimeoutMs": 1500,
  "Attempts": 3,
  "RetryDelayMs": 300,
  "DisconnectGraceMs": 1200
}
```

`EnableTriggerIp` آدرس اتصال و `DisableTriggerIp` آدرس قطع است. آدرس‌ها باید متفاوت و IPv4 باشند. فایل را ذخیره کنید و برنامه را دوباره باز کنید. مقادیر جدید در بالای پنجره نمایش داده می‌شوند.

آدرس‌های جدید باید در Ruleهای Trigger و آدرس‌های Control روتر نیز تنظیم شده باشند. تغییر فایل برنامه به‌تنهایی تنظیمات MikroTik را تغییر نمی‌دهد.

## تغییر پیش‌فرض پروژه

برای تغییر پیش‌فرضی که به کاربران جدید تحویل می‌دهید، این فایل پروژه را ویرایش کنید:

```text
src\Pbr.Client\appsettings.json
```

اگر می‌خواهید مقادیر fallback هنگام نبود فایل تنظیمات هم تغییر کنند، مقادیر پیش‌فرض را در `src\Pbr.Core\ClientSettings.cs` نیز عوض کنید.

برای تغییر ظاهر و رفتار:

- `src\Pbr.Client\MainWindow.xaml`: رابط برنامه.
- `src\Pbr.Client\MainWindow.xaml.cs`: رفتار دکمه‌ها و نمایش وضعیت.
- `src\Pbr.Core\TriggerService.cs`: منطق Ping و Retry.

فایل `MikroTikPBRClient.sln` را در Visual Studio باز کنید. برای اجرا، پروژه `Pbr.Client` را Startup Project قرار دهید. ساخت خروجی مستقل با `Build.cmd` و .NET 8 SDK انجام می‌شود. فایل‌های ساخت MSI در پوشه `installer` قرار دارند.
