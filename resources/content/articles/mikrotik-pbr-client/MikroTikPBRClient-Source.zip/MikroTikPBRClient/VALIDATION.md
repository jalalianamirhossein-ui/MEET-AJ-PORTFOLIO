# Delivery validation

## User-confirmed application and MSI delivery

The user confirmed that Portable-v1.0.2 works on their Windows system. The installer uses that same payload without application-code changes.

The MSI was compiled with wixl/msitools 0.103 and checked for x64 architecture, per-user installation, the no-elevation summary flag, installation under LocalAppDataFolder, three application/settings shortcuts, HKCU-only authored registry values, and the NeverOverwrite flag on the JSON configuration component. All 254 files extracted from its embedded cabinet were compared byte for byte (SHA-256) with the working portable payload; every file matched.

MSI installation, repair and uninstall have not been executed on Windows in this environment. The downloadable source includes the installer generator, generated WiX-compatible authoring and build instructions. Automatic upgrades are not implemented in this first MSI edition.

## Current package: Portable-v1.0.2 (folder deployment)

After the user reported another missing Desktop Runtime dialog, delivery was changed to an unbundled self-contained folder with a new archive filename. The precise executable used for the repeated screenshot could not be established; a stale download is possible but has not been verified.

The current package uses an ordinary Windows x64 GUI apphost with hostfxr.dll, hostpolicy.dll, coreclr.dll, the application DLL, dependency/runtime manifests, and the .NET/Windows Desktop libraries alongside it. The application runtimeconfig has no framework/frameworks entries that require a shared framework. This supersedes the single-file delivery described below.

- Built the ordinary Windows apphost with the application's icon and manifest.
- Included and checked the app-local Windows x64 hosting/runtime libraries.
- Ran the equivalent unbundled Linux self-contained startup layout with no global DOTNET_ROOT. Host tracing confirmed app-local hostfxr and self-contained runtime resolution; all eight mock checks passed, exit code 0.
- Included Start.cmd to check required files before launch and Diagnose.cmd to produce a local startup trace if launching fails.
- Verified Windows x64 PE subsystem and dependency-file closure; archive integrity checked.

The Windows WPF window and actual router behavior still have not been executed in this environment. Keep the entire extracted folder together; moving only the EXE discards its runtime dependencies.

## Completed

- Compiled core C# and the mock-check executable with Microsoft .NET SDK 8.0.425 / Roslyn, against the .NET 8.0.31 reference assemblies. Nullable analysis and warnings-as-errors enabled.
- Ran all eight mock checks successfully. Tests cover exact ON/OFF destinations, success without extra sends, retry after timeout, exhausted retries, PingException handling, cancellation before send, invalid settings, and explicit OFF without previous local state.
- Compiled App.xaml and MainWindow.xaml to generated C# / BAML with Microsoft's PresentationBuildTasks 8.0.31. No second markup pass required.
- Compiled the WPF application and Pbr.Core.dll successfully against Microsoft.WindowsDesktop.App.Ref 8.0.31, with warnings-as-errors.
- Created a Windows x64 GUI **singlefilehost**, including the application's icon and asInvoker manifest, with Microsoft.NET.HostModel. This host includes the startup hosting components needed for a self-contained bundle.
- Bundled the application, dependency/runtime manifests, and official Microsoft .NET / Windows Desktop 8.0.31 runtime files into a self-contained executable using Microsoft.NET.HostModel's single-file bundler.
- Verified the output is an x64 PE executable with Windows GUI subsystem.

## Corrected startup packaging

The original delivery used the ordinary `apphost.exe` template for a single-file bundle. That template needs an external hostfxr before it can process the bundle. Although the application/runtime assemblies were bundled, the bootstrap host was incomplete. On a computer without .NET, this produced the reported "You must install .NET Desktop Runtime" dialog.

The revised executable uses the official `singlefilehost.exe` from Microsoft.NETCore.App.Host.win-x64 8.0.31 instead. This is the template the SDK uses for self-contained single-file publication. The C# application, UI, and ON/OFF destinations are unchanged.

A platform-neutral bootstrap comparison was executed on Linux, using the corresponding official Linux x64 host templates with identical self-contained test payloads and no global .NET installation:

- Ordinary apphost bundle: reproduced the missing-runtime failure, exit code 131 / 0x80008083, hostfxr not found.
- Correct singlefilehost bundle: started using its bundled runtime, passed all eight mock checks, exit code 0.
- Host traces confirmed internal hostfxr and self-contained startup for the corrected launcher.

This comparison verifies the bootstrap correction. It does **not** establish that the Windows WPF window has been launched here.

## Build environment limitation

The ordinary dotnet CLI/MSBuild entry points could not run a build in this Linux execution environment because their process-information initialization failed. The delivered executable was instead produced by invoking the SDK's Roslyn compiler, WPF markup compiler, resource writer, apphost writer and bundler directly. The included Build.cmd uses the normal supported dotnet publish workflow on Windows; that command itself was not executed successfully here.

## Not verified here

- Launching/rendering the WPF window on Windows.
- Actual ICMP requests to 10.10.10.10 or 11.11.11.11.
- MikroTik address-list changes, scheduler execution, NAT/FastTrack behavior or public-IP changes.

No router was accessed or modified. The executable is unsigned. Successful ICMP replies are shown as acknowledged requests, not confirmed routing state.

## Windows acceptance test

1. Extract the portable archive; keep appsettings.json beside MikroTikPBRClient.exe.
2. Configure both trigger addresses to terminate at the intended local MikroTik, especially the public address 11.11.11.11.
3. Launch the application. Initial status must be unknown and no trigger should be sent automatically.
4. Click the power button. Verify a reply, green button, client membership in PBR-ACTIVE and the intended egress path.
5. Click again. After the grace period, verify removal from PBR-ACTIVE and ordinary egress.
6. Reopen the app and use Send disconnect; it must send OFF regardless of prior local state.
7. Test with an unreachable trigger: state must become unknown rather than claiming connection success.
8. Close the app: no automatic disconnect request should be sent.

For a standard rebuild, run Build.cmd on Windows with the .NET 8 SDK installed. Run Check.cmd for the mock tests.
