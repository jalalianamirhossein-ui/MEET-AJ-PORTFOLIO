@echo off
setlocal
cd /d "%~dp0"
dotnet run --project "tests\Pbr.Core.Checks\Pbr.Core.Checks.csproj" -c Release
if errorlevel 1 (
    echo Checks failed.
    pause
    exit /b 1
)
pause
